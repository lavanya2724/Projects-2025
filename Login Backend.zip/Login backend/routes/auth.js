const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const User = require('../models/User');

router.post('/register', async (req, res)=>{
    console.log("Register route hit");
    console.log("Request Body:",req.body);

    try{
        const{name,email,password} = req.body;

         if(!name || !email || !password) {
            console.log("Missing input fields");
            return res.status(400).json({ message:'All fields required'});

         }
         const existingUser = await User.findOne({ email});
         console.log("Existing User check result:", existingUser);

         if(existingUser){
            return res.status(400).json({ message:'User already exists'});
         }

         const hashedPassword = await bcrypt.hash(password,10);
         const newUser = new User({
            name,
            email,
            password: hashedPassword
         });

         const savedUser = await newUser.save();
         console.log(" User saved:", savedUser);

         return res.status(201).json({ message: 'User registered successfully'});
         } catch (err){
        console.error("Error in /register route:", err.message);
        return res.status(500).json({message : 'registered successfully'});
    }

});

    router.post('/login', async (req, res) => {
    console.log("Login route hit");
    console.log("Request Body:", req.body);

    try {
        const { email, password } = req.body;

        if (!email || !password) {
            console.log("Missing input fields");
            return res.status(400).json({ message: "All fields required" });
        }

        const user = await User.findOne({ email });  // lowercase variable
        console.log("User lookup result:", user);

        if (!user) {
            console.log("User not found");
            return res.status(400).json({ message: 'Invalid email or password' });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        console.log("Password match:", isMatch);

        if (!isMatch) {
            console.log("Incorrect password");
            return res.status(400).json({ message: 'Invalid email or password' });
        }

        console.log("Login successful for User:", user.email);
        return res.status(200).json({
            message: 'Login successful',
            User: {
                id: user._id,
                name: user.name,
                email: user.email
            }
        });

    } catch (err) {
        console.error("Error in /login route:", err.message);
        return res.status(500).json({ message: 'Login failed', error: err });
    }
});
module.exports =   router;