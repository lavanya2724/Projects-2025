const express = require("express");
const Product = require("../models/product.models.js");
const router = express.Router();
const  {getProducts, getProduct, createProduct, updateProduct, deleteProduct} =require('../controllers/product.controller.js');


router.get('/', getProduters);
router.get("/:id", getProduct);

router.post("/", createProduct);

router.put("/:id", updateProduct);

router.delete("/:id", deleteProduct);

module.exports = Product;